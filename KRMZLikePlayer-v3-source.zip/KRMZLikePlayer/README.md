# KRMZ Like Player

A minimal offline Android video player prototype designed around:
- single tap on the video surface toggles Play/Pause
- no persistent playback controls over the video
- local video playback from Android's document picker
- optional SRT subtitle loading
- full-screen immersive playback

## Build
Open this folder in Android Studio with an Android SDK installed, then build the debug APK.

Package: `com.amer.krmzlike`
Min Android: 7.0 (API 24)
Target/Compile: API 35
