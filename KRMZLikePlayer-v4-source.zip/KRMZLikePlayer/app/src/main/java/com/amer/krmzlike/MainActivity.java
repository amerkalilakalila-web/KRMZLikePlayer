package com.amer.krmzlike;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements SurfaceHolder.Callback {
    private static final int PICK_VIDEO = 100;
    private static final int PICK_SUBTITLE = 101;
    private static final String PREFS = "playback_positions";

    private FrameLayout root;
    private VideoSurfaceView surface;
    private MediaPlayer player;
    private Uri currentVideo;
    private TextView subtitleView;
    private TextView timeOverlay;
    private TextView timeLabel;
    private SeekBar seekBar;
    private LinearLayout controlPanel;
    private Button playPauseButton;
    private Button back10Button;
    private Button forward10Button;
    private Button muteButton;

    private Handler handler = new Handler();
    private Handler subtitleHandler = new Handler();
    private List<SubtitleCue> cues = new ArrayList<>();
    private Runnable positionSaveRunnable;
    private Runnable controlHideRunnable;
    private Runnable progressRunnable;
    private boolean userSeeking = false;
    private boolean muted = false;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hideSystemBars();
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        showPicker();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void showPicker() {
        stopPlayer();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(48, 48, 48, 48);
        box.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("KRMZ Like Player");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 24);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        Button open = new Button(this);
        open.setText("اختر فيديو");
        open.setOnClickListener(v -> pickVideo());
        box.addView(open);

        Button sub = new Button(this);
        sub.setText("اختيار ترجمة SRT (اختياري)");
        sub.setOnClickListener(v -> pickSubtitle());
        box.addView(sub);

        TextView hint = new TextView(this);
        hint.setText("نقرة واحدة على أي مكان في الفيديو = تشغيل/إيقاف.\nعند النقر تظهر عناصر التحكم السفلية مؤقتًا.");
        hint.setTextColor(Color.LTGRAY);
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 24, 0, 0);
        box.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        setContentView(box);
    }

    private void pickVideo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("video/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_VIDEO);
    }

    private void pickSubtitle() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("text/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_SUBTITLE);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        Uri u = data.getData();
        if (req == PICK_VIDEO) {
            currentVideo = u;
            playVideo(u);
        } else if (req == PICK_SUBTITLE) {
            loadSubtitle(u);
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView makeLabel(float sizeSp) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sizeSp);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setShadowLayer(5, 0, 0, Color.BLACK);
        return t;
    }

    private Button makeControlButton(String text, float sizeSp) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(sizeSp);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(7), 0, dp(7), 0);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private void playVideo(Uri uri) {
        stopPlayer();
        currentVideo = uri;

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        surface = new VideoSurfaceView(this);
        surface.getHolder().addCallback(this);
        FrameLayout.LayoutParams surfaceParams = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
        root.addView(surface, surfaceParams);

        subtitleView = makeLabel(21);
        subtitleView.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, -2,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        sp.setMargins(dp(30), 0, dp(30), dp(66));
        root.addView(subtitleView, sp);

        // Same top-center time readout style as KRMZ.
        timeOverlay = makeLabel(15);
        timeOverlay.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tp.setMargins(dp(12), dp(16), dp(12), 0);
        root.addView(timeOverlay, tp);

        // Transparent bottom controls: no large dark rectangle over the picture.
        controlPanel = new LinearLayout(this);
        controlPanel.setOrientation(LinearLayout.VERTICAL);
        controlPanel.setPadding(dp(10), 0, dp(10), dp(4));
        controlPanel.setBackgroundColor(Color.TRANSPARENT);

        seekBar = new SeekBar(this);
        seekBar.setMax(1000);
        seekBar.setPadding(0, 0, 0, 0);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser && player != null && player.getDuration() > 0) {
                    long position = (long) progress * player.getDuration() / 1000L;
                    if (timeLabel != null) timeLabel.setText(formatTime(position) + " / " + formatTime(player.getDuration()));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {
                userSeeking = true;
                showControls(false);
            }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                if (player != null && player.getDuration() > 0) {
                    int position = (int) ((long) bar.getProgress() * player.getDuration() / 1000L);
                    player.seekTo(position);
                }
                userSeeking = false;
                showControls(true);
            }
        });

        LinearLayout timeRow = new LinearLayout(this);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);
        timeRow.setGravity(Gravity.CENTER_VERTICAL);
        timeRow.setPadding(0, 0, 0, 0);

        playPauseButton = makeControlButton("▶", 19);
        back10Button = makeControlButton("↶ 10", 15);
        forward10Button = makeControlButton("10 ↷", 15);
        muteButton = makeControlButton("◖)))", 13);
        timeLabel = makeLabel(14);
        timeLabel.setGravity(Gravity.CENTER_VERTICAL);
        timeLabel.setText("00:00 / 00:00");

        timeRow.addView(playPauseButton, new LinearLayout.LayoutParams(-2, dp(44)));
        timeRow.addView(back10Button, new LinearLayout.LayoutParams(-2, dp(44)));
        timeRow.addView(forward10Button, new LinearLayout.LayoutParams(-2, dp(44)));
        timeRow.addView(muteButton, new LinearLayout.LayoutParams(-2, dp(44)));
        timeRow.addView(timeLabel, new LinearLayout.LayoutParams(-2, dp(44)));

        View rowSpacer = new View(this);
        timeRow.addView(rowSpacer, new LinearLayout.LayoutParams(0, 1, 1f));

        TextView fullscreen = makeLabel(23);
        fullscreen.setText("⛶");
        fullscreen.setGravity(Gravity.CENTER);
        fullscreen.setPadding(dp(8), 0, dp(8), 0);
        fullscreen.setOnClickListener(v -> hideSystemBars());
        timeRow.addView(fullscreen, new LinearLayout.LayoutParams(-2, dp(44)));

        controlPanel.addView(seekBar, new LinearLayout.LayoutParams(-1, dp(26)));
        controlPanel.addView(timeRow, new LinearLayout.LayoutParams(-1, dp(44)));

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM);
        root.addView(controlPanel, cp);

        playPauseButton.setOnClickListener(v -> {
            togglePlayPause();
            showControls(true);
        });
        back10Button.setOnClickListener(v -> seekBy(-10000));
        forward10Button.setOnClickListener(v -> seekBy(10000));
        muteButton.setOnClickListener(v -> toggleMute());

        surface.setOnTouchListener(new View.OnTouchListener() {
            long down;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    down = System.currentTimeMillis();
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP &&
                        System.currentTimeMillis() - down < 450) {
                    togglePlayPause();
                    showControls(true);
                    return true;
                }
                return true;
            }
        });

        controlPanel.setVisibility(View.GONE);
        timeOverlay.setVisibility(View.GONE);

        setContentView(root);
        hideSystemBars();
    }

    @Override public void surfaceCreated(SurfaceHolder h) {
        try {
            player = new MediaPlayer();
            player.setDisplay(h);
            player.setDataSource(this, currentVideo);
            player.setOnPreparedListener(mp -> {
                mp.setScreenOnWhilePlaying(true);
                restorePlaybackPosition(mp);
                surface.setVideoSize(mp.getVideoWidth(), mp.getVideoHeight());
                surface.requestLayout();
                updateProgressUi();
                mp.start();
                updatePlayButton();
                startSubtitleTicker();
                startPositionSaver();
                startProgressTicker();
            });
            player.setOnCompletionListener(mp -> {
                savePlaybackPosition();
                clearSavedPosition();
                updatePlayButton();
                stopBackgroundTasks();
            });
            player.prepareAsync();
        } catch (Exception e) {
            Toast.makeText(this, "تعذر تشغيل الفيديو", Toast.LENGTH_LONG).show();
            showPicker();
        }
    }

    @Override public void surfaceDestroyed(SurfaceHolder h) {
        if (player != null) player.setDisplay(null);
    }

    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int he) {}

    private void togglePlayPause() {
        if (player == null) return;
        if (player.isPlaying()) {
            player.pause();
            savePlaybackPosition();
        } else {
            player.start();
        }
        updatePlayButton();
        updateProgressUi();
    }

    private void updatePlayButton() {
        if (playPauseButton != null) playPauseButton.setText(player != null && player.isPlaying() ? "❚❚" : "▶");
    }

    private void toggleMute() {
        if (player == null) return;
        muted = !muted;
        float volume = muted ? 0f : 1f;
        try {
            player.setVolume(volume, volume);
            muteButton.setText(muted ? "×)))" : "◖)))");
            showControls(true);
        } catch (Exception ignored) {}
    }

    private void seekBy(int deltaMs) {
        if (player == null) return;
        try {
            int current = player.getCurrentPosition();
            int duration = player.getDuration();
            int target = Math.max(0, Math.min(duration, current + deltaMs));
            player.seekTo(target);
            updateProgressUi();
            showControls(true);
        } catch (Exception ignored) {}
    }

    private void showControls(boolean autoHideWhenPlaying) {
        if (controlPanel == null || player == null) return;
        controlPanel.setVisibility(View.VISIBLE);
        timeOverlay.setVisibility(View.VISIBLE);
        updateProgressUi();

        if (controlHideRunnable != null) handler.removeCallbacks(controlHideRunnable);
        if (autoHideWhenPlaying && player.isPlaying() && !userSeeking) {
            controlHideRunnable = () -> {
                if (controlPanel != null) controlPanel.setVisibility(View.GONE);
                if (timeOverlay != null) timeOverlay.setVisibility(View.GONE);
            };
            handler.postDelayed(controlHideRunnable, 3500);
        }
    }

    private void updateProgressUi() {
        if (player == null) return;
        try {
            long position = player.getCurrentPosition();
            long duration = Math.max(0, player.getDuration());
            if (timeLabel != null) timeLabel.setText(formatTime(position) + " / " + formatTime(duration));
            if (timeOverlay != null) timeOverlay.setText(formatTime(position) + " / " + formatTime(duration));
            if (seekBar != null && duration > 0 && !userSeeking) {
                seekBar.setProgress((int) ((position * 1000L) / duration));
            }
            updatePlayButton();
        } catch (Exception ignored) {}
    }

    private void startProgressTicker() {
        if (progressRunnable != null) handler.removeCallbacks(progressRunnable);
        progressRunnable = new Runnable() {
            @Override public void run() {
                updateProgressUi();
                handler.postDelayed(this, 500);
            }
        };
        handler.post(progressRunnable);
    }

    private String formatTime(long millis) {
        if (millis < 0) millis = 0;
        long totalSeconds = millis / 1000;
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;
        if (hours > 0) return String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds);
        return String.format(Locale.US, "%02d:%02d", minutes, seconds);
    }

    private String positionKey() {
        return currentVideo == null ? null : "pos_" + currentVideo.toString();
    }

    private void restorePlaybackPosition(MediaPlayer mp) {
        String key = positionKey();
        if (key == null) return;
        long saved = prefs.getLong(key, 0L);
        try {
            if (saved > 3000 && saved < mp.getDuration() - 5000) mp.seekTo((int) saved);
        } catch (Exception ignored) {}
    }

    private void savePlaybackPosition() {
        String key = positionKey();
        if (key == null || player == null) return;
        try {
            long pos = player.getCurrentPosition();
            long dur = player.getDuration();
            if (dur > 0 && pos < dur - 5000) prefs.edit().putLong(key, pos).apply();
        } catch (Exception ignored) {}
    }

    private void clearSavedPosition() {
        String key = positionKey();
        if (key != null) prefs.edit().remove(key).apply();
    }

    private void startPositionSaver() {
        if (positionSaveRunnable != null) handler.removeCallbacks(positionSaveRunnable);
        positionSaveRunnable = new Runnable() {
            @Override public void run() {
                savePlaybackPosition();
                handler.postDelayed(this, 1500);
            }
        };
        handler.postDelayed(positionSaveRunnable, 1500);
    }

    private void stopBackgroundTasks() {
        if (positionSaveRunnable != null) handler.removeCallbacks(positionSaveRunnable);
        positionSaveRunnable = null;
        if (progressRunnable != null) handler.removeCallbacks(progressRunnable);
        progressRunnable = null;
    }

    private void stopPlayer() {
        stopBackgroundTasks();
        // The subtitle ticker is intentionally stopped by cancelling all pending callbacks.
        subtitleHandler.removeCallbacksAndMessages(null);
        if (controlHideRunnable != null) handler.removeCallbacks(controlHideRunnable);
        controlHideRunnable = null;

        if (player != null) {
            savePlaybackPosition();
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    private void loadSubtitle(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            cues.clear();
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.contains("-->")) continue;
                String[] parts = line.split("-->");
                if (parts.length < 2) continue;
                long a = parseTime(parts[0].trim());
                long b = parseTime(parts[1].trim().split(" ")[0]);
                StringBuilder text = new StringBuilder();
                while ((line = br.readLine()) != null && !line.trim().isEmpty()) {
                    if (text.length() > 0) text.append('\n');
                    text.append(line.trim());
                }
                cues.add(new SubtitleCue(a, b, text.toString()));
            }
            Toast.makeText(this, "تم تحميل الترجمة", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "تعذر قراءة ملف الترجمة", Toast.LENGTH_LONG).show();
        }
    }

    private long parseTime(String s) {
        String[] p = s.replace(',', '.').split(":");
        double sec = 0;
        for (String x : p) sec = sec * 60 + Double.parseDouble(x);
        return (long) (sec * 1000);
    }

    private void startSubtitleTicker() {
        subtitleHandler.removeCallbacksAndMessages(null);
        Runnable subtitleTick = new Runnable() {
            public void run() {
                updateSubtitle();
                subtitleHandler.postDelayed(this, 150);
            }
        };
        subtitleHandler.post(subtitleTick);
    }

    private void updateSubtitle() {
        if (player == null || cues.isEmpty() || subtitleView == null) return;
        long t = player.getCurrentPosition();
        String text = "";
        for (SubtitleCue c : cues) {
            if (t >= c.start && t <= c.end) { text = c.text; break; }
        }
        subtitleView.setText(text);
    }

    @Override protected void onPause() {
        savePlaybackPosition();
        super.onPause();
    }

    @Override protected void onDestroy() {
        savePlaybackPosition();
        stopPlayer();
        super.onDestroy();
    }

    private static class SubtitleCue {
        long start, end;
        String text;
        SubtitleCue(long s, long e, String t) { start = s; end = e; text = t; }
    }

    @Override public void onBackPressed() {
        if (player != null) showPicker(); else super.onBackPressed();
    }

    private static class VideoSurfaceView extends SurfaceView {
        private int videoWidth;
        private int videoHeight;

        VideoSurfaceView(Context context) {
            super(context);
            setBackgroundColor(Color.BLACK);
        }

        void setVideoSize(int width, int height) {
            videoWidth = width;
            videoHeight = height;
        }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int parentWidth = MeasureSpec.getSize(widthMeasureSpec);
            int parentHeight = MeasureSpec.getSize(heightMeasureSpec);
            if (videoWidth <= 0 || videoHeight <= 0 || parentWidth <= 0 || parentHeight <= 0) {
                setMeasuredDimension(parentWidth, parentHeight);
                return;
            }

            float scale = Math.min((float) parentWidth / videoWidth,
                    (float) parentHeight / videoHeight);
            int width = Math.max(1, Math.round(videoWidth * scale));
            int height = Math.max(1, Math.round(videoHeight * scale));
            setMeasuredDimension(width, height);
        }
    }
}
